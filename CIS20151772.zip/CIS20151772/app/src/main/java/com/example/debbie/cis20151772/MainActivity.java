package com.example.debbie.cis20151772;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    public void Open_Directory (View view) {

        Intent directory = new Intent(this, Directory.class );

        startActivity(directory);
    }

    public void Open_Events (View view) {

        Intent event = new Intent(Intent.ACTION_VIEW, Uri.parse("http://cis.ncu.edu.jm/#events") );

        startActivity(event);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
