package com.example.debbie.cis20151772;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;

public class Directory extends Activity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directory);
    }

}
